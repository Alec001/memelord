<?php
	require('header.php');
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body align = "center">
	<div class="alert alert-success">
	<?php
		echo "<h1>Answer successfully updated. </h1>" ;
		echo "View your answers <a href='ans.php'>here</a>.";
	?>
	</div>
</body>
</html>
<?php
  require('footer.php');
?>
