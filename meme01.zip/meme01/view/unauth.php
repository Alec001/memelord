<?php
	session_start();
	require('header.php');
	require('checkUser.php');
?>

<h2 align="center">Oops! You are not authorised to do this.</h2>
<p align="center">Click <a href="userhome.php">here</a> to return to homepage.</p>
<?php
  require('footer.php');
?>
