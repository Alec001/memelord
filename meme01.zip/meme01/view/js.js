function function1() {
    
    var checkBox = document.getElementById("check1");
    
    var text = document.getElementById("p1");

    if (checkBox.checked == "true"){
        text.style.display = "block";
    } else {
        text.style.display = "none";
    }
}

function function2() {

    var checkBox = document.getElementById("check2");

    var text = document.getElementById("p2");

    if (checkBox.checked == "true"){
        text.style.display = "block";
    } else {
        text.style.display = "none";
    }
}
function function3() {

    var checkBox = document.getElementById("check3");

    var text = document.getElementById("p3");

    if (checkBox.checked == "true"){
        text.style.display = "block";
    } else {
        text.style.display = "none";
    }
}
function function4() {

    var checkBox = document.getElementById("check4");

    var text = document.getElementById("p4");

    if (checkBox.checked == "true"){
        text.style.display = "block";
       
    } else {
        text.style.display = "none";
    }
}
function function5() {

    var checkBox = document.getElementById("check5");

    var text = document.getElementById("p5");

    if (checkBox.checked == "true"){
        text.style.display = "block";
       
    } else {
        text.style.display = "none";
    }
}
function function6() {

    var checkBox = document.getElementById("check6");

    var text = document.getElementById("p6");

    if (checkBox.checked == "true"){
        text.style.display = "block";
       
    } else {
        text.style.display = "none";
    }
}








function regi() {
uname_error.innerHTML = '';
pass_error.innerHTML = '';
name_error.innerHTML = '';
email_error.innerHTML = '';


     if(uname.checkValidity() == false || uname.value == '') {
     document.getElementById('regierror').style.display = 'block';
    }

      if(pass.checkValidity() == false || pass.value == '') {
     document.getElementById('regierror').style.display = 'block';
    }
      if(name.checkValidity() == false || name.value == '') {
     document.getElementById('regierror').style.display = 'block';
    }
      if(email.checkValidity() == false || email.value == '') {
     document.getElementById('regierror').style.display = 'block';
    }



}

function forgot() {
    forg_error.innerHTML = '';


     if(forg.checkValidity() == false || forg.value == '') {
     document.getElementById('forgerror').style.display = 'block';
    }

}

function function1() {
    
    var checkBox = document.getElementById("check1");
    
    var text = document.getElementById("p1");

    if ( checkBox.checked == "true" ){
        text.style.display = "block";
    } else {
        text.style.display = "none";
    }
}

function function2() {

    var checkBox = document.getElementById("check2");

    var text = document.getElementById("p2");

    if ( checkBox.checked == "true"){
        text.style.display = "block";
    } else {
        text.style.display = "none";
    }
}
function function3() {

    var checkBox = document.getElementById("check3");

    var text = document.getElementById("p3");

    if ( text.style.display == "none"){
        text.style.display = "block";
        check3.style.display = "none";
    } else {
        text.style.display = "none";
    }
}
function function4() {

    var checkBox = document.getElementById("check4");

    var text = document.getElementById("p4");

    if ( text.style.display == "none"){
        text.style.display = "block";
        check4.style.display = "none";
    } else {
        text.style.display = "none";
    }
}
function function5() {

    var checkBox = document.getElementById("check5");

    var text = document.getElementById("p5");

    if ( text.style.display == "none"){
        text.style.display = "block";
        check5.style.display = "none";
    } else {
        text.style.display = "none";
    }
}
function function6() {

    var checkBox = document.getElementById("check6");

    var text = document.getElementById("p6");

    if ( text.style.display == "none"){
        text.style.display = "block";
        check1.style.display = "none";
    } else {
        text.style.display = "none";
    }
}
