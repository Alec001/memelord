<?php
	require('header.php');
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body align = "center">
	<div class="alert alert-success">
	<?php
		echo "<h2> Thank you for contacting us. We will revert back shortly.</h2> " ;
		echo "<a href='home.php'>Click Here</a> to log-in";
	?>
	</div>
</body>
</html>
<?php
  require('footer.php');
?>
