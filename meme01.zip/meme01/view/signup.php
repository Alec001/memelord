<?php
	session_start();
	require('header.php');
?>

<!DOCTYPE html>
<html>
<head>
    
	<style>
		.error {color: #FF0000}
        
        #p1 {display: none; margin : 0 auto;}
        #p2 {display: none; margin : 0 auto;}
        #p3 {display: none; margin : 0 auto;}
        #p4 {display: none; margin : 0 auto;}
        #p5 {display: none; margin : 0 auto;}
        
        #loader {
            display: none; margin : 0 auto;
        }
        
        /* Container */
.container{
    margin: 0 auto;
    width: 70%;
}

/* Registration */
#div_reg{
    border: 1px solid gray;
    border-radius: 3px;
    width: 470px;
    height: 370px;
    box-shadow: 0px 2px 2px 0px  gray;
    margin: 0 auto;
}

#div_reg h1{
    margin-top:0px;
    font-weight: normal;
    padding:10px;
    background-color:cornflowerblue;
    color:white;
    font-family:sans-serif;
}

#div_reg div{
    clear: both;
    margin-top: 10px;
    padding: 5px;
}

#div_reg .textbox{
    width: 96%;
    padding: 7px;
}

#div_reg input[type=submit]{
    padding: 7px;
    width: 100px;
    background-color: lightseagreen;
    border: 0px;
    color: white;
}

/* Response */
.response{
    padding: 6px;
    display: none;
}

.not-exists{
    color: green;
}

.exists{
    color: red;
}
        
        .cen {
            margin: 0 auto;
            
        }  
        
        #userc {
            display: none;
            margin: 0 auto;
            
        }
        
        
        .modal {
    display:    none;
    position:   fixed;
    z-index:    1000;
    top:        0;
    left:       0;
    height:     100%;
    width:      100%;
    background: rgba( 255, 255, 255, .8 ) 
                url('http://sampsonresume.com/labs/pIkfp.gif') 
                50% 50% 
                no-repeat;
}

/* When the body has the loading class, we turn
   the scrollbar off with overflow:hidden */
body.loading {
    overflow: hidden;   
}

/* Anytime the body has the loading class, our
   modal element will be visible */
body.loading .modal {
    display: block;
}
	</style>
	
    <script type="text/javascript">
        
        
        
        
        
        $(document).ready(function () {
            $('#check1').click(function () {
                
                $.ajax({
                    url: 'check_availability.php',
                    type: 'POST',
                    data: {
                        username: $('#username').val()
                    },
                    beforeSend: function(){
                  $("#loader").show(); 
                  $("#status").css("display","none")
                },
                    
                   complete: function(){
                       setTimeout(function() { 
        $("#loader").css("display","none");
    }, 2000);
                setTimeout(function() { 
        $("#status").css("display","block");
    }, 2000);       }, 
                    
                    
                    success: function (data) {
                        $('#status').html(data);
                    }
                       
            
                });
                    
            });
            
        });
          $(document).ready(function () {
            $('#sub1').click(function () {
                
                $.ajax({
                    url: 'check_availability.php',
                    type: 'POST',
                    data: {
                        username: $('#username').val()
                    },
                    beforeSend: function(){
                  $("#loader").show(); 
                  $("#status").css("display","none")
                },
                    
                   complete: function(){
                       setTimeout(function() { 
        $("#loader").css("display","none");
    }, 2000);
                setTimeout(function() { 
        $("#status").css("display","block");
    }, 2000);       }, 
                    
                    
                    success: function (data) {
                        $('#status').html(data);
                    }
                       
            
                });
                    
            });
            
        });
        
         
        
        $(document).ready(function () {
            $('#userc').click(function () {
                
                $.ajax({
                    url: 'check_availability.php',
                    type: 'POST',
                    data: {
                        username: $('#username').val()
                    },
                    beforeSend: function(){
                  $("#loader").show(); 
                  $("#status").css("display","none")
                },
                    
                   complete: function(){
                       setTimeout(function() { 
        $("#loader").css("display","none");
    }, 2000);
                setTimeout(function() { 
        $("#status").css("display","block");
    }, 2000);       }, 
                    
                    
                    success: function (data) {
                        $('#status').html(data);
                    }
                       
            
                });
                    
            });
            
        });
        
         $(document).ready(function () {
            $('#check4').click(function () {
                $.ajax({
                    url: 'emailCheck.php',
                    type: 'GET',
                    data: {
                        email: $('#email').val()
                    },
                    beforeSend: function(){
                  $("#loader").show();
                 $("#status2").css("display","none")
                },
                   complete: function(){
                  setTimeout(function() { 
        $("#loader").css("display","none");
    }, 2000);
                setTimeout(function() { 
        $("#status2").css("display","block");
    }, 2000);       }, 
                   
                    success: function (data) {
                        $('#status2').html(data);
                    }
                });
            });
            
        });
        
        
        
       /* $(function(){
            
            $('#username').on('keyup', function(){
                var username = $(this).val();
                var $input = $(this);
                
                if(username){
                    $.ajax({
                        url: 'check_availability.php',
                        method: 'get',
                        data: {username: username},
                        success: function(response){
                            
                            response = $.parseJSON(response);
                            
                            if(response.status == 'success') {
                                
                                $input.css('border', 'solid 2px red');
                                $('#status').text('Sorry, this username is already taken')
                            } else {
                                $input.css('border', 'solid 2px #2196F3');
                                $('#status').text('');
                            }
                            console.log(response)
                        }
                    });
                }
            });
        });
        */
        
        
        
/*function checkAvailability() {
	$("#loaderIcon").show();
	jQuery.ajax({
	url: "check_availability.php",
	data:'uname='+$("#uname").val(),
	type: "GET",
	success:function(data){
		$("#user-availability-status").html(data);
		$("#loaderIcon").hide();
	},
	error:function (){}
	});
}*/
</script>
    
</head>
<body align="center">

	<h2>User Sign-up Form</h2>
	<p><span class = "error">All fields are compulsory.</span></p>
    <p><span class = "error">Please tick the check box when you have completed each field.</span></p>
    
	<form method="post" class="form-inline cen" action="../model/addUser.php" id="reg"  >
		<div class="form-group">
    <label for="username">Username</label>
   <div class="form-group">
       <input type="text" id="username" name="username" class="username form-control cen" pattern="[a-zA-Z0-9]{3,20}" >
       <div id="loader" class="modal">
       </div>
       <div class="status" id="status">
       
       </div>
		</div>
  </div>
<input type="checkbox" id="check1" onclick="function1()">
<input type="button" id="userc" value="Check Username Availability">
		<br>
  
		<div id="p1">
         <div class="form-group">
    <label for="pass">Password</label>
   <div class="form-group">
       <input type="password" id="pass" name="pass" class="form-control cen">
            <aside id="uname_error" title="Please enter a Password"></aside>
		</div>
  </div>
    <input type="checkbox" id="check2" onclick="function2()">
    </div>
        
        <div id="p2">
		<div class="form-group">
            <label for="name">Name</label>
			 <input type="text" id="name" name="name" class="form-control cen" pattern="[a-zA-Z]{3,20}">
            <aside id="name_error" title="Please enter a name"></aside>
		</div>
  <input type="checkbox" id="check3" onclick="function3()">
        </div>
   
		
<div id="p3">
		<div class="form-group">
            <label for="email">Email</label>
			<input type="email" id="email" name="email" class="form-control cen">
            <div id="status2">
            
            </div>
            
		</div>
    <input type="checkbox" id="check4" onclick="function4()">
            </div>
     
		
<div id="p4">
    <label for="radio">Gender</label>
		<div class="radio" id="radio">
			<input type="radio" id="male" name="gender" value="female">Female
			<input type="radio" id="female" name="gender" value="male">Male
</div> 
    <input type="checkbox" id="check5" onclick="function5()">
    </div>
		
<div id="p5">
		<input type="submit" name="submit" value="Submit" class="btn btn-primary sub1" id="sub1" onclick="check_availability.php">
		<input type="reset" name="reset" value="Reset" class="btn btn-primary">
    </div>

		<?php
			if(isset($_GET["act"]))
				if($_GET["act"] == "invalid"){ 
                    
        
?>
        
<script type="text/javascript">
    $(document).ready(function(){
        $("#loginerr").modal('show');
    });</script>        
<!-- Modal -->
<div class="modal fade" id="loginerr" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Login Error</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        The Username or Password you entered was incorrect
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
        
        
        
        
        
        <?php 
                    
                }
        ?>
        
	</form>
 <div class="alert alert-danger" align="center" id="regierror" style="display: none;">
         <h3 style="color: red; text-align: center;">Please complete all fields</h3>
        </div>
</body>
</html>
<?php
  require('footer.php');
?>
