<html>

<?php
	session_start();
	require('header.php');

	echo "<h3 align='center'>This is Contact Us page.</h3>"
?>




<form method="post" class="form-inline" action="enquiry.php" align="center" name="contact" id="contact">
    <label for="name">Name</label>
	 <input type="text" id="name1" pattern="[a-zA-Z\s]{2,30}">
    <br>
    <label for="email">Email</label>
	<input type="email" name="email" id="email1"  oninvalid="this.setCustomValidity('Please Enter a Valid Email')" oninput="setCustomValidity('')">
    <br>
    <label for="msg">Message</label>
	<input type="text" name="msg" id="msg" pattern="[a-zA-Z0-9\s]{6,255}">
    <br>
	<input type="submit" name="Submit" id="contsub" class="btn btn-primary" onclick="contact()">
</form>
<?php
        require('footer.php');
?>

<?php
	if(isset($_GET["act"])){
		if($_GET["act"] == "invalid"){
			echo '<div class="alert alert-danger" align="center">';
			echo "Username does not exist.";
			echo "</div>";
		}
	}
?>
</html>