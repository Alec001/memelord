<?php
$email = $_GET['email'];

if (empty($email)) {
     echo 'Please enter an Email';
} else {
         $db = new PDO("mysql:host=localhost;dbname=meme", 'root','');
}

$query = $db->prepare("SELECT * FROM USER WHERE EMAIL = :email");

$query->execute(['email' => $email]);

if ($query->rowCount() < 1) {
echo '<strong>' . $email . '</strong> is available'; 
} else {
    echo 'Sorry, <strong>' . $email . '</strong> is already associated with an account.';
}

?>