
$(document).ready(function() {
  validate();
  $('input').on('keyup', validate);
    $('input').on('click', validate);
    
   
});


function validate() {
  var inputsWithValues = 0;
  
  // get all input fields except for type='submit'
  var myInputs = $('input, textarea').not(':input[type=submit], :input[type=file]');  
  myInputs.each(function(e) {
    // if it has a value, increment the counter
    if ($(this).val()) {
      inputsWithValues += 1;
    }
  });

  if (inputsWithValues == myInputs.length) {
    $("input[type=submit]").prop("disabled", false);
  } else {
    $("input[type=submit]").prop("disabled", true);
  }
}











/*
function contact(){

var name = document.getElementById('name1').value;
var email = document.getElementById('email1').value;
var message = document.getElementById('msg').value;
    
     name1_error.innerHTML = '';
    email1_error.innerHTML = '';
    msg_error.innerHTML = '';

if(name.contact() == false || name.value == '') {
     document.getElementById('contsub').disabled=true;
    }
    
    if(email.contact() == false || email.value == '') {
        document.getElementById('contsub').disabled=true;
    }
    
    if(message.contact() == false || message.value == '') {
       document.getElementById('contsub').disabled=true;
    }

    
if(document.getElementById('contsub').disabled=true){
document.getElementById('contsub').disabled=true;
}else{
document.getElementById('contsub').disabled=false;   
}

}

*/




/*
function contact() {
    name1_error.innerHTML = '';
    email1_error.innerHTML = '';
    msg_error.innerHTML = '';
    
if(name1.checkValidity() == false || name1.value == '') {
     document.getElementById('name1_error').style.display = 'block';
    }
    
    if(email1.checkValidity() == false || email1.value == '') {
        document.getElementById('email1_error').style.display = 'block';
    }
    
    if(msg.checkValidity() == false || msg.value == '') {
        document.getElementById('msg_error').style.display = 'block';
    }
    
    if(name1.value != '' && email1.value != '' && msg.value != '') {
        
//        window.location = 'localhost/meme01/view/enquiry.php';
    }
    
}


*/

function function1() {
    
    var checkBox = document.getElementById("check1");
    
    var text = document.getElementById("p1");
    
    var button = document.getElementById("userc")

    if (checkBox.checked == true){
        text.style.display = "block";
        checkBox.style.display = "none";
        button.style.display = "block";
        
    } else {
        text.style.display = "none";
    }
}

function function2() {

    var checkBox = document.getElementById("check2");

    var text = document.getElementById("p2");

    if (checkBox.checked == true){
        text.style.display = "block";
        checkBox.style.display = "none";
    } else {
        text.style.display = "none";
    }
}

function function3() {

    var checkBox = document.getElementById("check3");

    var text = document.getElementById("p3");

    if (checkBox.checked == true){
        text.style.display = "block";
        checkBox.style.display = "none";
    } else {
        text.style.display = "none";
    }
}

function function4() {

    var checkBox = document.getElementById("check4");

    var text = document.getElementById("p4");

    if (checkBox.checked == true){
        text.style.display = "block";
        checkBox.style.display = "none";
    } else {
        text.style.display = "none";
    }
}

function function5() {

    var checkBox = document.getElementById("check5");

    var text = document.getElementById("p5");

    if (checkBox.checked == true){
        text.style.display = "block";
        checkBox.style.display = "none";
    } else {
        text.style.display = "none";
    }
}

function function6() {

    var checkBox = document.getElementById("check6");

    var text = document.getElementById("p6");

    if (checkBox.checked == true){
        text.style.display = "block";
        checkBox.style.display = "none";
    } else {
        text.style.display = "none";
    }
}






function regi() {
uname_error.innerHTML = '';
pass_error.innerHTML = '';
name_error.innerHTML = '';
email_error.innerHTML = '';


     if(uname.checkValidity() == false || uname.value == '') {
     document.getElementById('regierror').style.display = 'block';
    }

      if(pass.checkValidity() == false || pass.value == '') {
     document.getElementById('regierror').style.display = 'block';
    }
      if(name.checkValidity() == false || name.value == '') {
     document.getElementById('regierror').style.display = 'block';
    }
      if(email.checkValidity() == false || email.value == '') {
     document.getElementById('regierror').style.display = 'block';
    }



}

function forgot() {
    forg_error.innerHTML = '';


     if(forg.checkValidity() == false || forg.value == '') {
     document.getElementById('forgerror').style.display = 'block';
    }

}

