<?php
	require('header.php');
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body align = "center">
	<div class="alert alert-success">
	<?php
		echo "<h1>New topic successfully added. </h1>" ;
		echo "<h3>View all categories <a href='userhome.php'>here</a>.";
	?>
	</div>
</body>
</html>
<?php
  require('footer.php');
?>
