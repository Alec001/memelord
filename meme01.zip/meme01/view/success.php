<?php
	require('header.php');
?>

<!DOCTYPE html>
<html>
<head>
	
</head>
<body align = "center">
	<div class="alert alert-success">
	<?php
		echo "<h1> You are registered </h1> " ;
		echo "<a href='home.php'>Click Here</a> to log-in";
	?>
	</div>
</body>
</html>
<?php
  require('footer.php');
?>
