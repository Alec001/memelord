<?php
	session_start();
	require('header.php');


	echo "<h3 align='center'>About Us</h3>";


  require('footer.php');
?>
