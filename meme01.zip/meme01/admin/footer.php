<?php
require 'Mobile_Detect.php';
$detect = new Mobile_Detect;
$deviceType = ($detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'phone') : 'computer');
?>


<?php
$check = $detect->isMobile();
 if($check == true) {
     echo '<div style="position:fixed; ">';
     echo '<h3>This is a Mobile</h3>';
     echo '</div>';
 } else {
     echo '<div style="position: fixed; bottom:93%;">';
     echo '<h3>This is a Desktop</h3>';
     echo '</div>';
 }
?>

<?php
echo '<div style="position:fixed; bottom:0%;">';
var_dump($_SESSION);
echo '</pre>';
var_dump($_GET);
echo '</pre>';
var_dump($_POST);
echo '</pre>';
echo '<div>';


?>
